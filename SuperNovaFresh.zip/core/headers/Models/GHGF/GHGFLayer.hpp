#pragma once
#include "../../NeuromorphicTimeSpace/VagueTemoraryPremativeFabric.hpp"

namespace BidirectionalInMemGraph
{

    struct GHGFLearningConfig final
    {
        float HCouplingLearningRate = 1.0e-3f;
        float DriftLearningRate = 1.0e-3f;

        float VolatilityLearningRate = 1.0e-4f;
        float VCouplingLearningRate = 1.0e-4f;

        float AutoConnectionLearningRate = 1.0e-4f;

        float GradientClip = 10.0f;

        float MinTonicLogVolatility = -20.0f;
        float MaxTonicLogVolatility = 10.0f;
    };


    struct StructuralLearningGHGF
    {        
        using EB = EdgeBuilder;

        enum class GHGFConcurrentOperation : uint8_t
        {
            SUCCESS = 0,
            REJECTED = 1,
            RETRY = 2,
            STALE = 3,
        };

        struct GHGFStructureMutation final
        {
            EB::StructureOperation Operation = EB::StructureOperation::ADD_PARENT;
            uint32_t Child = ADS::APC_INDEX_BOUND_SENTINAL;
            uint32_t OldParent = ADS::APC_INDEX_BOUND_SENTINAL;
            uint32_t NewParent = ADS::APC_INDEX_BOUND_SENTINAL;
            FabricSegments Edge = FabricSegments::VALUE_PARENT_EDGE_TABLE_H;
            float Coupling = 1.0f;
            uint32_t ExpectedRowSequence = UINT32_MAX;
        };

        struct GHGFStructureSnapshot final
        {
            uint32_t Child = ADS::APC_INDEX_BOUND_SENTINAL;
            FabricSegments Edge = FabricSegments::VALUE_PARENT_EDGE_TABLE_H;
            uint32_t RowSequence = UINT32_MAX;
            uint64_t ParentMask = UNSIGNED_ZERO;
            bool IsValid = false;
        };

        struct GHGFStructureMutationResult final
        {
            GHGFConcurrentOperation Result = GHGFConcurrentOperation::REJECTED;
            uint32_t PublishedRowSequence = UINT32_MAX;
            uint32_t PublishedOrdinal = EB::RELATION_NULL;
        };

        struct GHGFParentExecutionSnapshot final
        {
            uint64_t ParentMask = UNSIGNED_ZERO;
            uint32_t RowSequence = UINT32_MAX;
            std::array<EB::ParentIDGeneration, ADS::GHGF_MAX_DIRECTED_PARENT_PER_AXIS > ParentHandles{};
            std::array<float, ADS::GHGF_MAX_DIRECTED_PARENT_PER_AXIS > Couplings{};
        };
    };

    class GHGFLayerModel : public StructuralLearningGHGF
    {

    public:
        using SD = SchemaDefinition;
        static constexpr uint32_t DEFAULT_BATCH_CAPACITY = 32u;

        enum class GHGFNodeRole : uint8_t
        {
            OBSERVATION = 1,
            VALUE = 2,
            VOLATILE = 3
        };

        enum class GHGFStateRow : uint8_t
        {
            MEAN = 0,
            EXPECTED_MEAN = 1,
            PRECISION = 2,
            EXPECTED_PRECISION = 3,
            CONDITIONAL_EXPECTED_PRECISION = 4,
            OBSERVED = 5,
            CURRENT_VARIANCE = 6,
            EFFECTIVE_PRECISION = 7
        };
        static constexpr uint8_t STATE_ROW_COUNT_HEIGHT = static_cast<uint8_t>(GHGFStateRow::EFFECTIVE_PRECISION) + 1;

        enum class GHGFErrorRow : uint8_t
        {
            VALUE_PREDICTION_ERROR = 0,
            VOLATILE_PREDICTION_ERROR = 1
        };
        static constexpr uint8_t ERROR_ROW_COUNT_HEIGHT = static_cast<uint8_t>(GHGFErrorRow::VOLATILE_PREDICTION_ERROR) + 1;

        enum class GHGFErrorValueIndexing : uint8_t
        {
            TONIC_VOLATILE = 0,
            TONIC_DRIFT = 1,
            AUTO_CONNECTION = 2
        };
        static constexpr uint8_t FIRST_COUPLING_INDEX = static_cast<uint8_t>(GHGFErrorValueIndexing::AUTO_CONNECTION) + 1;

        static constexpr uint8_t WEIGHT_ROW_HEIGHT = 1u;

        enum class GHGFMessageFForward : uint8_t
        {
            OBSERVATION = 0,
            VALUE_FACTOR = 1,
            VALUE_GAIN = 2,
            VALUE_ERROR = 3,
            EFFECTIVE_PRECISION = 4,
            VALUE_LEARNING_SIGNAL = 5,
            VOLATILE_ERROR = 6
        };
        static constexpr uint8_t FF_MESSEGE_LEN_GHGF = static_cast<uint8_t>(GHGFMessageFForward::VOLATILE_ERROR) + 1u;

        enum class GHGFMessageFBackward : uint8_t
        {
            MEAN = 0,
            EXPECTED_MEAN = 1,
            EXPECTED_PRECISION = 2
        };
        static constexpr uint8_t FB_MESSEGE_LEN_GHGF = static_cast<uint8_t>(GHGFMessageFBackward::EXPECTED_PRECISION) + 1u;



        struct GHGFStorageProfile final
        {
            uint32_t BatchCapacity = UNSIGNED_ZERO;
            uint32_t RequiredAPCCells = UNSIGNED_ZERO;
            uint32_t ParameterCount = UNSIGNED_ZERO;
            uint16_t ActiveRegionMask = UNSIGNED_ZERO;
            uint8_t MaxDirectParentPerAxis = ADS::DEFAULT_DIRECTED_PARENT_PER_AXIS;

            SD::FabricRegionConfig FabricConfig{};
            SD::RegionSchemaTable DefaultSchemaTable{};
            bool IsValid = false;
        };

        struct GHGFConnection
        {
            uint32_t Parent;
            uint32_t Child;
            FabricSegments Edge;
            float Coupling = 1.0f;
        };

        struct GHGFParameterRange
        {
            uint32_t Slot;
            uint32_t Index;
            float Lower;
            float Upper;
        };

        static constexpr uint32_t CouplingIndex(
            FabricSegments edge_table,
            uint32_t relation_ordinal,
            uint32_t max_direct_parent_per_axis
        ) noexcept
        {
            if (
                relation_ordinal >= max_direct_parent_per_axis ||
                (edge_table != FabricSegments::VALUE_PARENT_EDGE_TABLE_H &&
                 edge_table != FabricSegments::VOLATILE_PARENT_EDGE_TABLE_V)
            )
            {
                return ADS::APC_INDEX_BOUND_SENTINAL;
            }

            const uint32_t axis_offset =
                edge_table == FabricSegments::VOLATILE_PARENT_EDGE_TABLE_V
                    ? static_cast<uint32_t>(max_direct_parent_per_axis)
                    : UNSIGNED_ZERO;

            return FIRST_COUPLING_INDEX + axis_offset + relation_ordinal;
        }

        static constexpr bool MakeDefaultGHGFStorageProfile(
            GHGFStorageProfile& profile,
            uint32_t batch_capacity = DEFAULT_BATCH_CAPACITY,
            uint8_t max_direct_parent_per_axis = ADS::DEFAULT_DIRECTED_PARENT_PER_AXIS,
            bool is_default_profile = true
        ) noexcept
        {
            profile = GHGFStorageProfile{};
            SD::MakeDisabledSchemaTable(profile.DefaultSchemaTable);

            if (
                batch_capacity == UNSIGNED_ZERO ||
                max_direct_parent_per_axis == UNSIGNED_ZERO ||
                max_direct_parent_per_axis > ADS::GHGF_MAX_DIRECTED_PARENT_PER_AXIS 
            )
            {
                return false;
            }

            const uint32_t parameter_count = FIRST_COUPLING_INDEX + (EDGE_COUNT * static_cast<uint32_t>(max_direct_parent_per_axis));

            if (!SD::AttachPrivateFloat32ToTable_(
                profile.DefaultSchemaTable,
                MacroColumnOfAPC::BOTTOM_UP_SLOT,
                FF_MESSEGE_LEN_GHGF,
                batch_capacity,
                SD::SchemaFlags::BATCHED_LAST_DIM
            ))
            {
                return false;
            }

            if (!SD::AttachPrivateFloat32ToTable_(
                profile.DefaultSchemaTable,
                MacroColumnOfAPC::TOP_DOWN_SLOT,
                FB_MESSEGE_LEN_GHGF,
                batch_capacity,
                SD::SchemaFlags::BATCHED_LAST_DIM
            ))
            {
                return false;
            }
            
            if (!SD::AttachPrivateFloat32ToTable_(
                profile.DefaultSchemaTable,
                MacroColumnOfAPC::STATE_SLOT,
                STATE_ROW_COUNT_HEIGHT,
                batch_capacity,
                SD::SchemaFlags::BATCHED_LAST_DIM
            ))
            {
                return false;
            }
            
            if (!SD::AttachPrivateFloat32ToTable_(
                profile.DefaultSchemaTable,
                MacroColumnOfAPC::ERROR_SLOT,
                ERROR_ROW_COUNT_HEIGHT,
                batch_capacity,
                SD::SchemaFlags::BATCHED_LAST_DIM
            ))
            {
                return false;
            }

            if (!SD::AttachPrivateFloat32ToTable_(
                profile.DefaultSchemaTable,
                MacroColumnOfAPC::WEIGHT_SLOT,
                WEIGHT_ROW_HEIGHT,
                parameter_count,
                SD::SchemaFlags::NONE
            ))
            {
                return false;
            }

            profile.BatchCapacity = batch_capacity;
            profile.MaxDirectParentPerAxis = max_direct_parent_per_axis;
            profile.ParameterCount = parameter_count;
            profile.ActiveRegionMask = SD::GetActiveMaskOfRegionTable_(profile.DefaultSchemaTable);
            profile.RequiredAPCCells = SD::RequiredCellsForSchemaTable_(profile.DefaultSchemaTable);

            if (
                profile.ActiveRegionMask == UNSIGNED_ZERO ||
                profile.RequiredAPCCells == UNSIGNED_ZERO
            )
            {
                return false;
            }
            
            profile.FabricConfig.ActiveRegionMask = profile.ActiveRegionMask;
            profile.FabricConfig.Reserved = UNSIGNED_ZERO;
            profile.FabricConfig.BatchCapacity = profile.BatchCapacity;

            profile.IsValid = true;
            profile.FabricConfig.IsDefault = is_default_profile;

            return true;
        }

        static constexpr bool IsValidStoregeProfile(const GHGFStorageProfile& profile) noexcept
        {
            const uint32_t expected_paremeter_count = FIRST_COUPLING_INDEX + (EDGE_COUNT * static_cast<uint32_t>(profile.MaxDirectParentPerAxis));

            const uint16_t expected_mask = static_cast<uint16_t>(
                ADS::RegionBit(MacroColumnOfAPC::BOTTOM_UP_SLOT) |
                ADS::RegionBit(MacroColumnOfAPC::TOP_DOWN_SLOT) |
                ADS::RegionBit(MacroColumnOfAPC::STATE_SLOT) |
                ADS::RegionBit(MacroColumnOfAPC::ERROR_SLOT) |
                ADS::RegionBit(MacroColumnOfAPC::WEIGHT_SLOT)
            );        

            const SD::RegionSchemaRecord& ff = profile.DefaultSchemaTable[static_cast<uint8_t>(MacroColumnOfAPC::BOTTOM_UP_SLOT)];
            const SD::RegionSchemaRecord& fb = profile.DefaultSchemaTable[static_cast<uint8_t>(MacroColumnOfAPC::TOP_DOWN_SLOT)];
            const SD::RegionSchemaRecord& state = profile.DefaultSchemaTable[static_cast<uint8_t>(MacroColumnOfAPC::STATE_SLOT)];
            const SD::RegionSchemaRecord& error = profile.DefaultSchemaTable[static_cast<uint8_t>(MacroColumnOfAPC::ERROR_SLOT)];
            const SD::RegionSchemaRecord& weight = profile.DefaultSchemaTable[static_cast<uint8_t>(MacroColumnOfAPC::WEIGHT_SLOT)];

            return
                profile.IsValid &&
                profile.BatchCapacity != UNSIGNED_ZERO &&
                profile.MaxDirectParentPerAxis != UNSIGNED_ZERO &&
                profile.MaxDirectParentPerAxis <= ADS::GHGF_MAX_DIRECTED_PARENT_PER_AXIS  &&
                profile.ParameterCount == expected_paremeter_count &&
                profile.ActiveRegionMask == expected_mask &&
                profile.FabricConfig.ActiveRegionMask == expected_mask &&
                profile.FabricConfig.Reserved == UNSIGNED_ZERO &&
                profile.FabricConfig.BatchCapacity == profile.BatchCapacity &&
                ADS::IsCapacityOfAPCValid(profile.RequiredAPCCells) &&
                SD::GetActiveMaskOfRegionTable_(profile.DefaultSchemaTable) == expected_mask &&
                SD::RequiredCellsForSchemaTable_(profile.DefaultSchemaTable) == profile.RequiredAPCCells &&

                ff.Region == MacroColumnOfAPC::BOTTOM_UP_SLOT &&
                ff.Dtype == SD::DataTypeOfMacroColumn::FLOAT32_T &&
                ff.Protocol == SD::SchemaProtocols::PRIVATE_REGION &&
                ff.MatrixHeight == FF_MESSEGE_LEN_GHGF &&
                ff.MatrixWidth == profile.BatchCapacity &&
                ff.Flags == SD::SchemaFlags::BATCHED_LAST_DIM &&

                fb.Region == MacroColumnOfAPC::TOP_DOWN_SLOT &&
                fb.Dtype == SD::DataTypeOfMacroColumn::FLOAT32_T &&
                fb.Protocol == SD::SchemaProtocols::PRIVATE_REGION &&
                fb.MatrixHeight == FB_MESSEGE_LEN_GHGF &&
                fb.MatrixWidth == profile.BatchCapacity &&
                fb.Flags == SD::SchemaFlags::BATCHED_LAST_DIM &&

                state.Region == MacroColumnOfAPC::STATE_SLOT &&
                state.Dtype == SD::DataTypeOfMacroColumn::FLOAT32_T &&
                state.Protocol == SD::SchemaProtocols::PRIVATE_REGION &&
                state.MatrixHeight == STATE_ROW_COUNT_HEIGHT &&
                state.MatrixWidth == profile.BatchCapacity &&
                state.Flags == SD::SchemaFlags::BATCHED_LAST_DIM &&

                error.Region == MacroColumnOfAPC::ERROR_SLOT &&
                error.Dtype == SD::DataTypeOfMacroColumn::FLOAT32_T &&
                error.Protocol == SD::SchemaProtocols::PRIVATE_REGION &&
                error.MatrixHeight == ERROR_ROW_COUNT_HEIGHT &&
                error.MatrixWidth == profile.BatchCapacity &&
                error.Flags == SD::SchemaFlags::BATCHED_LAST_DIM &&

                weight.Region == MacroColumnOfAPC::WEIGHT_SLOT &&
                weight.Dtype == SD::DataTypeOfMacroColumn::FLOAT32_T &&
                weight.Protocol == SD::SchemaProtocols::PRIVATE_REGION &&
                weight.MatrixHeight == WEIGHT_ROW_HEIGHT &&
                weight.MatrixWidth == profile.ParameterCount &&
                weight.Flags == SD::SchemaFlags::NONE;
        }


        static constexpr bool IsHCouplingParameter(uint32_t index, uint8_t max_direct_parent_per_edge) noexcept
        {
            const uint32_t end = FIRST_COUPLING_INDEX + static_cast<uint32_t>(max_direct_parent_per_edge);
            return 
                index >= FIRST_COUPLING_INDEX && index < end;
        }

        
        struct GHGFCache final
        {
            uint32_t FFCellOffset_ = UNSIGNED_ZERO;
            uint32_t FBCellOffset_ = UNSIGNED_ZERO;
            uint32_t StateCellOffset_ = UNSIGNED_ZERO;
            uint32_t ErrorCellOffset_ = UNSIGNED_ZERO;
            uint32_t WeightCellOffset_ = UNSIGNED_ZERO;
            uint32_t NodeCount_ = UNSIGNED_ZERO;
            uint32_t ObservationCount_ = UNSIGNED_ZERO;
            bool ModelPrepared_ = false;
            bool StructuralLearningActive_ = false;
        };

        struct StorageConst
        {
            // Initial storage contents.
            static constexpr float INITIAL_STORAGE_VALUE = 0.0f;

            // Initial beliefs and prediction state.
            static constexpr float INITIAL_BINARY_PROBABILITY = 0.5f;
            static constexpr float INITIAL_PRECISION = 1.0f;
            // Baseline dynamics; tonic volatility is stored on a logarithmic scale.
            static constexpr float OBSERVATION_TONIC_LOG_VOLATILITY = 0.0f;
            static constexpr float INITIAL_TONIC_LOG_VOLATILITY = -4.0f;
            static constexpr float INITIAL_AUTO_CONNECTION = 1.0f;
            // Initial strengths for connected H and V parents.
            static constexpr float INITIAL_VALUE_COUPLING = 1.0f;
            static constexpr float INITIAL_VOLATILITY_COUPLING = 1.0f;

            static constexpr float ZERO = 0.0f;
            static constexpr float ONE = 1.0f;
            static constexpr float HALF = 0.5f;
            static constexpr float BINARY_CLIP = 1.0e-6f;
            static constexpr float MIN_PRECISION = 1.0e-8f;
            static constexpr float MAX_PRECISION = 1.0e10f;
            static constexpr float INITIAL_SEARCH_STEP = 1.0f;
            static constexpr float MIN_SEARCH_STEP = 1.0e-3f;
            static constexpr uint32_t INVALID_SLOT = ADS::APC_INDEX_BOUND_SENTINAL;
        };
    };

    
}