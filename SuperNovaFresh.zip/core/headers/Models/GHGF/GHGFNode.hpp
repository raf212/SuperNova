#pragma once 
#include "GHGFLayer.hpp"
#include "../../AdaptivePackedCellContainer/AdaptivePackedCellContainer.hpp"

namespace BidirectionalInMemGraph
{
    class GHGFModel;
    class GHGFModelConstructor;

    class GHGFNode : protected AdaptivePackedCellContainer
    {
        friend class GHGFModel;
        friend class GHGFModelConstructor;
    private:
        using GM = GHGFLayerModel;


        GHGFModel* GHGFFabric_{nullptr};

        std::optional<GM::GHGFNodeRole> GHGFRole_() noexcept;

        std::optional<GM::GHGFNodeRole> IsLiveGHGFSlot_() noexcept
        {
            APCUseScope apc_use = AcquireAPCUse_();
            return apc_use ?  GHGFRole_() : std::nullopt;
        }

        bool PredictGHGFNodenNONVectorized_(uint32_t batch, uint32_t max_tries = DEFAULT_MAX_TRIES) noexcept;
        bool UpdateGHGFNodeNONVectorized_(uint32_t batch, uint32_t max_tries = DEFAULT_MAX_TRIES) noexcept;
        bool PropogateGHGFErrorNONVectorized_(uint32_t child, uint32_t batch, uint32_t max_tries = DEFAULT_MAX_TRIES) noexcept;

        bool PublishFForwardMessageGHGF_(uint32_t batch) noexcept;
        void PublishFBackwardMessageGHGF_(uint32_t batch) noexcept;

        void ResetAPCGHGFStateRegion_() noexcept;
    public:
        bool InitializeGHGFNode(
            GM::GHGFNodeRole role
        ) noexcept;

    };
    
}