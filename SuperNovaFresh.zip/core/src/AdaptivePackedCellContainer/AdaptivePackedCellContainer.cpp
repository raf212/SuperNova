#include <SuperNova>
namespace BidirectionalInMemGraph
{
    using MutationResult = AdaptivePackedCellContainer::MutationResult;

    bool AdaptivePackedCellContainer::IsOpenGeneration_() noexcept
    {
        return HandleOfAPCStatic::IsOpenGeneration(
            std::atomic_ref<uint64_t>(*APCCache_.GenerationCellPtr_).load(std::memory_order_acquire),
            APCCache_.CurrentGeneration_
        );
    }

    bool AdaptivePackedCellContainer::ResolveBridgeRegion(
        MacroColumnOfAPC column,
        uint32_t record_ordinal,
        ResolveRegionBiteView& out
    ) noexcept
    {
        using SD = SchemaDefinition;

        SD::ConstRSSpan region_row = APCCache_.FabricOwnerPtr_->MetrixViewRow_(APCCache_.APCSlotIdx_);
        out = ResolveRegionBiteView{};
        if (
            !IsActiveAPC() ||
            !APCCache_.RawAPCBasePtr_ ||
            region_row.size() != APCCache_.FabricOwnerPtr_->FabCache_->ActiveRegionCount_
        ) 
        {
            return false;
        }

        const std::optional<uint8_t> compact_index = ADS::CompactRegionIndex(
            APCCache_.FabricOwnerPtr_->FabCache_->ActiveRegionMask_, 
            column
        );
        if (!compact_index.has_value()) 
        {
            return false;
        }

        const SD::RegionSchemaRecord& stored = region_row[compact_index.value()];

        if (
            stored.Region != column ||
            !SD::ValidateStortedRegionSchema(
                stored,
                APCCache_.FabricOwnerPtr_->FabCache_->PerAPCRuntimeCellCount_,
                APCCache_.FabricOwnerPtr_->FabCache_->MatrixBatchCapacity_    
            )
        ) 
        {
            return false;
        }

        uint64_t matrix_bytes{};
        uint32_t matrix_cells{};
        uint32_t stride_cells{};
        uint32_t record_count{};

        if (
            !SD::GetALLRequiredComputerInfo(matrix_bytes, matrix_cells, stride_cells, record_count, stored) ||
            record_ordinal >= record_count
        ) 
        {
            return false;
        }

        const uint64_t local_data_cell = static_cast<uint64_t>(stored.CellOffset) + (static_cast<uint64_t>(record_ordinal) * stride_cells);

        if (
            local_data_cell >= APCCache_.FabricOwnerPtr_->FabCache_->PerAPCRuntimeCellCount_ ||
            matrix_cells > APCCache_.FabricOwnerPtr_->FabCache_->PerAPCRuntimeCellCount_ - local_data_cell
        ) 
        {
            return false;
        }

        out.Bytes = std::span<std::byte>(
            APCCache_.RawAPCBasePtr_ + static_cast<uint64_t>(local_data_cell) * sizeof(uint64_t),
            static_cast<uint64_t>(matrix_bytes)
        );
        out.Schema = &stored;
        out.RegionOrdinal = record_ordinal;
        return true;
    }

    MutationResult AdaptivePackedCellContainer::AddParent(
        AdaptivePackedCellContainer& parent,
        FabricSegments edge_table,
        uint32_t max_tries,
        uint32_t internal_recursion
    ) noexcept
    {
        if (
            !IsFabricBound_() ||
            !parent.IsFabricBound_() ||
            APCCache_.FabricOwnerPtr_ != parent.APCCache_.FabricOwnerPtr_ 
        )
        {
            return MutationResult::INVALID;
        }

        return APCCache_.FabricOwnerPtr_->AddParentRelation_(
                parent.APCCache_.APCSlotIdx_,
                parent.APCCache_.CurrentGeneration_,
                APCCache_.APCSlotIdx_,
                APCCache_.CurrentGeneration_,
                edge_table,
                nullptr,
                max_tries,
                internal_recursion
            );
    }

    MutationResult AdaptivePackedCellContainer::RemoveParent(
        AdaptivePackedCellContainer& parent,
        FabricSegments edge_table,
        uint32_t max_tries,
        uint32_t internal_recursion
    ) noexcept
    {
        if (
            !IsFabricBound_() ||
            !parent.IsFabricBound_() ||
            APCCache_.FabricOwnerPtr_ != parent.APCCache_.FabricOwnerPtr_ 
        )
        {
            return MutationResult::INVALID;
        }

        return APCCache_.FabricOwnerPtr_->RemoveParentRelation_(
                parent.APCCache_.APCSlotIdx_,
                parent.APCCache_.CurrentGeneration_,
                APCCache_.APCSlotIdx_,
                APCCache_.CurrentGeneration_,
                edge_table,
                nullptr,
                max_tries,
                internal_recursion
            );
    }

    MutationResult AdaptivePackedCellContainer::ReplaceParent(
        AdaptivePackedCellContainer& old_parent,
        AdaptivePackedCellContainer& new_parent,
        FabricSegments edge_table,
        uint32_t max_tries,
        uint32_t internal_recursion
    ) noexcept
    {
        if (
            &old_parent == &new_parent ||
            !IsFabricBound_() ||
            !old_parent.IsFabricBound_() ||
            !new_parent.IsFabricBound_() ||
            APCCache_.FabricOwnerPtr_ != old_parent.APCCache_.FabricOwnerPtr_ ||
            APCCache_.FabricOwnerPtr_ != new_parent.APCCache_.FabricOwnerPtr_ 
        )
        {
            return MutationResult::INVALID;
        }
        return APCCache_.FabricOwnerPtr_->ReplaceParentRelation_(
                old_parent.APCCache_.APCSlotIdx_,
                old_parent.APCCache_.CurrentGeneration_,
                new_parent.APCCache_.APCSlotIdx_,
                new_parent.APCCache_.CurrentGeneration_,
                APCCache_.APCSlotIdx_,
                APCCache_.CurrentGeneration_,
                edge_table,
                nullptr,
                max_tries,
                internal_recursion
            );
    }

    MutationResult AdaptivePackedCellContainer::AttachMyChild(
        AdaptivePackedCellContainer& child,
        FabricSegments edge_table,
        uint32_t max_tries,
        uint32_t internal_recursion
    ) noexcept
    {
        return child.AddParent(*this, edge_table, max_tries, internal_recursion);
    }

    MutationResult AdaptivePackedCellContainer::DetachMyChild(
        AdaptivePackedCellContainer& child,
        FabricSegments edge_table,
        uint32_t max_tries,
        uint32_t internal_recursion
    ) noexcept
    {
        return child.RemoveParent(*this, edge_table, max_tries, internal_recursion);
    }
    
    AdaptivePackedCellContainer AdaptivePackedCellContainer::FindParent(
        FabricSegments edge_table,
        uint32_t relation_ordinal,
        RelationOparation* parent_relation,
        uint32_t max_tries
    ) noexcept
    {
        return IsFabricBound_()
            ? APCCache_.FabricOwnerPtr_->FindParent_(
                APCCache_.APCSlotIdx_,
                APCCache_.CurrentGeneration_,
                edge_table,
                relation_ordinal,
                parent_relation,
                max_tries
            )
            : AdaptivePackedCellContainer{};
    }

    AdaptivePackedCellContainer AdaptivePackedCellContainer::FindFirstChild(
        FabricSegments edge_table,
        RelationOparation* child_relation,
        uint32_t max_tries
    ) noexcept
    {
        return IsFabricBound_()
            ? APCCache_.FabricOwnerPtr_->FindFirstChild_(
                APCCache_.APCSlotIdx_,
                APCCache_.CurrentGeneration_,
                edge_table,
                child_relation,
                max_tries
            )
            : AdaptivePackedCellContainer{};
    }

    AdaptivePackedCellContainer AdaptivePackedCellContainer::FindLastChild(
        FabricSegments edge_table,
        RelationOparation* child_relation,
        uint32_t max_tries
    ) noexcept
    {
        return IsFabricBound_()
            ? APCCache_.FabricOwnerPtr_->FindLastChild_(
                APCCache_.APCSlotIdx_,
                APCCache_.CurrentGeneration_,
                edge_table,
                child_relation,
                max_tries
            )
            : AdaptivePackedCellContainer{};
    }

    AdaptivePackedCellContainer AdaptivePackedCellContainer::FindNextChild(
        FabricSegments edge_table,
        uint32_t current_relation_locator,
        RelationOparation* child_relation,
        uint32_t max_tries
    ) noexcept
    {
        return IsFabricBound_()
            ? APCCache_.FabricOwnerPtr_->FindNextChild_(
                APCCache_.APCSlotIdx_,
                APCCache_.CurrentGeneration_,
                edge_table,
                current_relation_locator,
                child_relation,
                max_tries
            )
            : AdaptivePackedCellContainer{};
    }

    AdaptivePackedCellContainer AdaptivePackedCellContainer::FindPreviousChild(
        FabricSegments edge_table,
        uint32_t current_relation_locator,
        RelationOparation* child_relation,
        uint32_t max_tries
    ) noexcept
    {
        return IsFabricBound_()
            ? APCCache_.FabricOwnerPtr_->FindPreviousChild_(
                APCCache_.APCSlotIdx_,
                APCCache_.CurrentGeneration_,
                edge_table,
                current_relation_locator,
                child_relation,
                max_tries
            )
            : AdaptivePackedCellContainer{};
    }

    bool AdaptivePackedCellContainer::Retire(
        uint32_t max_tries
    ) noexcept
    {
        if (!IsFabricBound_())
        {
            return false;
        }

        APCFinilizer* owner = APCCache_.FabricOwnerPtr_;
        const uint32_t slot = APCCache_.APCSlotIdx_;
        const uint32_t generation = APCCache_.CurrentGeneration_;

        if (!owner->RetireAPC_(slot, generation, max_tries))
        {
            return false;
        }
        ReleseFabricBindingOnly_();
        return true;
    }
}