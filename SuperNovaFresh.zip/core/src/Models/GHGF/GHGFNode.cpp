#include "Models/GHGF/GHGFModelOfAPC.hpp"
#include <span>

namespace BidirectionalInMemGraph
{ 

    void GHGFNode::PublishFBackwardMessageGHGF_(uint32_t batch) noexcept
    {
        const uint32_t slot = APCCache_.APCSlotIdx_;
        std::copy_n(
            GHGFFabric_->GHGFStateRow_(slot, GM::GHGFStateRow::MEAN),
            batch,
            GHGFFabric_->FBRowGHGF_(slot, GM::GHGFMessageFBackward::MEAN)
        );

        std::copy_n(
            GHGFFabric_->GHGFStateRow_(slot, GM::GHGFStateRow::EXPECTED_MEAN),
            batch,
            GHGFFabric_->FBRowGHGF_(slot, GM::GHGFMessageFBackward::EXPECTED_MEAN)
        );

        std::copy_n(
            GHGFFabric_->GHGFStateRow_(slot, GM::GHGFStateRow::EXPECTED_PRECISION),
            batch,
            GHGFFabric_->FBRowGHGF_(slot, GM::GHGFMessageFBackward::EXPECTED_PRECISION)
        );
    }

    bool GHGFNode::PublishFForwardMessageGHGF_(uint32_t batch) noexcept
    {
        const uint32_t slot = APCCache_.APCSlotIdx_;
        const std::optional<GM::GHGFNodeRole> role = GHGFRole_();

        const float* marginal = GHGFFabric_->GHGFStateRow_(slot, GM::GHGFStateRow::EXPECTED_PRECISION);
        const float* precision = GHGFFabric_->GHGFStateRow_(slot, GM::GHGFStateRow::PRECISION);
        const float* conditional = GHGFFabric_->GHGFStateRow_(slot, GM::GHGFStateRow::CONDITIONAL_EXPECTED_PRECISION);
        const float* effictive = GHGFFabric_->GHGFStateRow_(slot, GM::GHGFStateRow::EFFECTIVE_PRECISION);
        const float* observed = GHGFFabric_->GHGFStateRow_(slot, GM::GHGFStateRow::OBSERVED);
        const float* value_error = GHGFFabric_->GHGFErrorRow_(slot, GM::GHGFErrorRow::VALUE_PREDICTION_ERROR);
        const float* volatile_error = GHGFFabric_->GHGFErrorRow_(slot, GM::GHGFErrorRow::VOLATILE_PREDICTION_ERROR);

        float* value_factor  = GHGFFabric_->FFRowGHGF_(slot, GM::GHGFMessageFForward::VALUE_FACTOR);
        float* value_gain = GHGFFabric_->FFRowGHGF_(slot, GM::GHGFMessageFForward::VALUE_GAIN);
        float* value_error_ff = GHGFFabric_->FFRowGHGF_(slot, GM::GHGFMessageFForward::VALUE_ERROR);
        float* effective_precision = GHGFFabric_->FFRowGHGF_(slot, GM::GHGFMessageFForward::EFFECTIVE_PRECISION);
        float* volatile_error_ff = GHGFFabric_->FFRowGHGF_(slot, GM::GHGFMessageFForward::VOLATILE_ERROR);
        float* value_learning_signal = GHGFFabric_->FFRowGHGF_(slot, GM::GHGFMessageFForward::VALUE_LEARNING_SIGNAL);

        if (role.value() == GM::GHGFNodeRole::OBSERVATION)
        {
            for (uint32_t i = 0; i < batch; i++)
            {
                value_factor[i] = marginal[i];
                value_gain[i] = marginal[i];
                value_error_ff[i] = value_error[i];
                value_learning_signal[i] = observed[i] != GM::StorageConst::ZERO
                        ? marginal[i] * value_error[i] : GM::StorageConst::ZERO;
                effective_precision[i] = GM::StorageConst::ZERO;
                volatile_error_ff[i] = GM::StorageConst::ZERO;
            }
            return true;
        }
        
        for (uint32_t i = 0; i < batch; i++)
        {
            const float information = precision[i] - marginal[i];
            const float denominator = conditional[i] + information;
            if (
                !std::isfinite(denominator) ||
                denominator <= GM::StorageConst::ZERO
            )
            {
                return false;
            }

            value_factor[i] = conditional[i] * information / denominator;
            value_gain[i] = conditional[i] * precision[i] / denominator;
            effective_precision[i] = effictive[i];
            volatile_error_ff[i] = volatile_error[i];
            value_error_ff[i] = value_error[i];
            value_learning_signal[i] = observed[i] != GM::StorageConst::ZERO 
                ? precision[i] * value_error[i] : GM::StorageConst::ZERO;
        }
        
        return true;
    }

    bool GHGFNode::InitializeGHGFNode(
        GHGFLayerModel::GHGFNodeRole role
    ) noexcept
    {
        using GMC = GM::StorageConst;
        using SD = SchemaDefinition;

        if (
            !GHGFFabric_ ||
            !GHGFFabric_->IsFabricActive() ||
            APCCache_.FabricOwnerPtr_ != static_cast<APCFinilizer*>(GHGFFabric_) ||
            !GM::IsValidStoregeProfile(GHGFFabric_->Profile_) || !IsActiveAPC()
        )
        {
            return false;
        }

        SNTOComputerBridge<float> state_view = BuildAViewOverRegion<float>(MacroColumnOfAPC::STATE_SLOT);
        SNTOComputerBridge<float> error_view = BuildAViewOverRegion<float>(MacroColumnOfAPC::ERROR_SLOT);
        SNTOComputerBridge<float> weight_view = BuildAViewOverRegion<float>(MacroColumnOfAPC::WEIGHT_SLOT);
        
        if (
            !state_view.IsValid() ||
            !error_view.IsValid() ||
            !weight_view.IsValid()
        )
        {
            return false;
        }
        
        std::optional<std::span<float>> state = state_view.RawSpan();
        std::optional<std::span<float>> error = error_view.RawSpan();
        std::optional<std::span<float>> weight = weight_view.RawSpan();
        

        if (
            !state.has_value() ||
            !error.has_value() ||
            !weight.has_value() ||
            state.value().size() != static_cast<size_t>(GM::STATE_ROW_COUNT_HEIGHT) * GHGFFabric_->Profile_.BatchCapacity ||
            error.value().size() != static_cast<size_t>(GM::ERROR_ROW_COUNT_HEIGHT) * GHGFFabric_->Profile_.BatchCapacity ||
            weight.value().size() != GHGFFabric_->Profile_.ParameterCount
        )
        {
            return false;
        }
        
        std::fill(state.value().begin(), state.value().end(), GMC::INITIAL_STORAGE_VALUE);
        std::fill(error.value().begin(), error.value().end(), GMC::INITIAL_STORAGE_VALUE);
        std::fill(weight.value().begin(), weight.value().end(), GMC::INITIAL_STORAGE_VALUE);

        const auto StateIndex___ = [&](GM::GHGFStateRow row, uint32_t batch) noexcept -> size_t
        {
            return (static_cast<size_t>(row) * GHGFFabric_->Profile_.BatchCapacity) + batch;
        };
        
        for (uint32_t batch = 0; batch < GHGFFabric_->Profile_.BatchCapacity; batch++)
        {
            (state.value())[StateIndex___(GM::GHGFStateRow::MEAN, batch)] = GMC::INITIAL_STORAGE_VALUE;
            if (role == GM::GHGFNodeRole::OBSERVATION)
            {
                (state.value())[StateIndex___(GM::GHGFStateRow::EXPECTED_MEAN, batch)] = GMC::INITIAL_BINARY_PROBABILITY;
            }
            else
            {
                (state.value())[StateIndex___(GM::GHGFStateRow::EXPECTED_MEAN, batch)] = GMC::INITIAL_STORAGE_VALUE;
            }

            (state.value())[StateIndex___(GM::GHGFStateRow::PRECISION, batch)] = GMC::INITIAL_PRECISION;
            (state.value())[StateIndex___(GM::GHGFStateRow::EXPECTED_PRECISION, batch)] = GMC::INITIAL_PRECISION;
            (state.value())[StateIndex___(GM::GHGFStateRow::CONDITIONAL_EXPECTED_PRECISION, batch)] = GMC::INITIAL_PRECISION;
            (state.value())[StateIndex___(GM::GHGFStateRow::OBSERVED, batch)] = GMC::INITIAL_PRECISION;
            (state.value())[StateIndex___(GM::GHGFStateRow::CURRENT_VARIANCE, batch)] = GMC::INITIAL_PRECISION;
            (state.value())[StateIndex___(GM::GHGFStateRow::EFFECTIVE_PRECISION, batch)] = GMC::INITIAL_STORAGE_VALUE;
        }

        (weight.value())[static_cast<size_t>(GM::GHGFErrorValueIndexing::TONIC_VOLATILE)] = role == GM::GHGFNodeRole::OBSERVATION?
            GMC::OBSERVATION_TONIC_LOG_VOLATILITY : GMC::INITIAL_TONIC_LOG_VOLATILITY;
        (weight.value())[static_cast<size_t>(GM::GHGFErrorValueIndexing::TONIC_DRIFT)] = GMC::INITIAL_STORAGE_VALUE;
        (weight.value())[static_cast<size_t>(GM::GHGFErrorValueIndexing::AUTO_CONNECTION)] = role == GM::GHGFNodeRole::OBSERVATION?
            GMC::INITIAL_STORAGE_VALUE : GMC::INITIAL_AUTO_CONNECTION;

        for (uint8_t i = 0; i < GHGFFabric_->Profile_.MaxDirectParentPerAxis; i++)
        {
            const uint32_t value_index = GM::CouplingIndex(
                FabricSegments::VALUE_PARENT_EDGE_TABLE_H,
                i,
                GHGFFabric_->Profile_.MaxDirectParentPerAxis
            );

            const uint32_t volatile_index = GM::CouplingIndex(
                FabricSegments::VOLATILE_PARENT_EDGE_TABLE_V,
                i,
                GHGFFabric_->Profile_.MaxDirectParentPerAxis
            );

            if (
                value_index >= weight.value().size() ||
                volatile_index >= weight.value().size()
            )
            {
                return false;
            }

            (weight.value())[value_index] = GMC::INITIAL_VALUE_COUPLING;
            (weight.value())[volatile_index] = GMC::INITIAL_VOLATILITY_COUPLING;
        }

        GMI::NodeModelDescription* model_desc = GHGFFabric_->NodeModel_(APCCache_.APCSlotIdx_);
        if (!model_desc) return false;

        const SD::ConstRSSpan schemas = GHGFFabric_->MetrixViewRow_(APCCache_.APCSlotIdx_);
        if (!schemas.empty())
        {
            model_desc->Instance = schemas.front().ModelInstance;
        }
        std::atomic_ref<uint32_t>(model_desc->Role).store(
            static_cast<uint32_t>(role),
            std::memory_order_release
        );

        GHGFFabric_->InvalidateGHGFModel_();
        return true;
    }


    void GHGFNode::ResetAPCGHGFStateRegion_() noexcept
    {
        std::fill_n(
            GHGFFabric_->GHGFRegion_(APCCache_.APCSlotIdx_, GHGFFabric_->GHGFCache_.FFCellOffset_),
            static_cast<size_t>(GM::FF_MESSEGE_LEN_GHGF) *
                GHGFFabric_->Profile_.BatchCapacity,
                GM::StorageConst::ZERO
        );
        std::fill_n(
            GHGFFabric_->GHGFRegion_(APCCache_.APCSlotIdx_, GHGFFabric_->GHGFCache_.FBCellOffset_),
            static_cast<size_t>(GM::FB_MESSEGE_LEN_GHGF) *
                GHGFFabric_->Profile_.BatchCapacity,
                GM::StorageConst::ZERO
        );
        std::fill_n(
            GHGFFabric_->GHGFRegion_(APCCache_.APCSlotIdx_, GHGFFabric_->GHGFCache_.StateCellOffset_),
            static_cast<size_t>(GM::STATE_ROW_COUNT_HEIGHT) * GHGFFabric_->Profile_.BatchCapacity, GM::StorageConst::ZERO
        );
        std::fill_n(
            GHGFFabric_->GHGFRegion_(APCCache_.APCSlotIdx_, GHGFFabric_->GHGFCache_.ErrorCellOffset_),
            static_cast<size_t>(GM::ERROR_ROW_COUNT_HEIGHT) * GHGFFabric_->Profile_.BatchCapacity, GM::StorageConst::ZERO
        );
        const float initial_mean = GHGFRole_() == GM::GHGFNodeRole::OBSERVATION ?
            GM::StorageConst::INITIAL_BINARY_PROBABILITY : GM::StorageConst::ZERO;

        for (uint32_t lane = 0; lane < GHGFFabric_->Profile_.BatchCapacity; ++lane)
        {
            GHGFFabric_->GHGFStateRow_(APCCache_.APCSlotIdx_, GM::GHGFStateRow::EXPECTED_MEAN)[lane] = initial_mean;
            GHGFFabric_->GHGFStateRow_(APCCache_.APCSlotIdx_, GM::GHGFStateRow::PRECISION)[lane] = GM::StorageConst::INITIAL_PRECISION;
            GHGFFabric_->GHGFStateRow_(APCCache_.APCSlotIdx_, GM::GHGFStateRow::EXPECTED_PRECISION)[lane] = GM::StorageConst::INITIAL_PRECISION;
            GHGFFabric_->GHGFStateRow_(APCCache_.APCSlotIdx_, GM::GHGFStateRow::CONDITIONAL_EXPECTED_PRECISION)[lane] = GM::StorageConst::INITIAL_PRECISION;
            GHGFFabric_->GHGFStateRow_(APCCache_.APCSlotIdx_, GM::GHGFStateRow::OBSERVED)[lane] = GM::StorageConst::ONE;
            GHGFFabric_->GHGFStateRow_(APCCache_.APCSlotIdx_, GM::GHGFStateRow::CURRENT_VARIANCE)[lane] = GM::StorageConst::ONE;
        }
    }

    std::optional<GHGFLayerModel::GHGFNodeRole> GHGFNode::GHGFRole_() noexcept
    {
        if (!IsActiveAPC()) return std::nullopt;
        GMI::NodeModelDescription* model_desc = GHGFFabric_->NodeModel_(APCCache_.APCSlotIdx_);
        if (!model_desc) return std::nullopt;
        const uint32_t value = std::atomic_ref<uint32_t>(model_desc->Role).load(std::memory_order_acquire);
        if (
            value < static_cast<uint8_t>(GM::GHGFNodeRole::OBSERVATION) ||
            value > static_cast<uint8_t>(GM::GHGFNodeRole::VOLATILE)
        )
        {
            return std::nullopt;
        }
        return static_cast<GM::GHGFNodeRole>(value);
    }

    bool GHGFNode::PredictGHGFNodenNONVectorized_(uint32_t batch, uint32_t max_tries) noexcept
    {
        using SR = GM::GHGFStateRow;
        using ER = GM::GHGFErrorRow;
        using FR = GM::GHGFMessageFBackward;
        using EI = GM::GHGFErrorValueIndexing;
        using SC = GM::StorageConst;

        const uint32_t slot = APCCache_.APCSlotIdx_;
        const auto value_axis = FabricSegments::VALUE_PARENT_EDGE_TABLE_H;
        const auto volatile_axis = FabricSegments::VOLATILE_PARENT_EDGE_TABLE_V;

        float* predicted = GHGFFabric_->GHGFStateRow_(slot, SR::EXPECTED_MEAN);
        float* marginal = GHGFFabric_->GHGFStateRow_(slot, SR::EXPECTED_PRECISION);
        const float* weight = GHGFFabric_->GHGFWeight_(slot);

        // Observation node: Bernoulli prediction from value parents.
        if (GHGFRole_() == GM::GHGFNodeRole::OBSERVATION)
        {
            const float bias = weight[static_cast<size_t>(EI::TONIC_DRIFT)];

            std::fill_n(predicted, batch, bias);
            GM::GHGFParentExecutionSnapshot parents{};
            if (
                GHGFFabric_->ReadGHGFParentExecutionSnapshot_(
                    slot,
                    value_axis,
                    parents,
                    max_tries
                ) != FabricToAPCLinker::SeqLockedOperation::FOUND
            )
            {
                return false;
            }

            for (
                uint64_t mask = parents.ParentMask;
                mask;
                mask &= mask - 1u
            )
            {
                const uint8_t ordinal = static_cast<uint8_t>(std::countr_zero(mask));
                const uint32_t parent = parents.ParentHandles[ordinal].Slot;
                const float coupling = parents.Couplings[ordinal];
                const float* parent_mean =
                    GHGFFabric_->FBRowGHGF_(
                        parent,
                        FR::EXPECTED_MEAN
                    );

                for (uint32_t lane = 0; lane < batch; ++lane)
                {
                    predicted[lane] +=
                        coupling * parent_mean[lane];
                }
            }

            for (uint32_t lane = 0; lane < batch; ++lane)
            {
                if (!std::isfinite(predicted[lane]))
                {
                    return false;
                }

                const float exponent = std::exp(-std::abs(predicted[lane]));

                const float probability =
                    predicted[lane] >= SC::ZERO
                        ? SC::ONE / (SC::ONE + exponent)
                        : exponent / (SC::ONE + exponent);

                predicted[lane] =
                    std::clamp(
                        probability,
                        SC::BINARY_CLIP,
                        SC::ONE - SC::BINARY_CLIP
                    );

                marginal[lane] = predicted[lane] * (SC::ONE - predicted[lane]);
            }

            PublishFBackwardMessageGHGF_(batch);
            return true;
        }


        const float* mean = GHGFFabric_->GHGFStateRow_(slot, SR::MEAN);
        const float* precision = GHGFFabric_->GHGFStateRow_(slot, SR::PRECISION);

        float* conditional =
            GHGFFabric_->GHGFStateRow_(slot, SR::CONDITIONAL_EXPECTED_PRECISION);
        float* current_variance =
            GHGFFabric_->GHGFStateRow_(slot, SR::CURRENT_VARIANCE);
        float* effective =
            GHGFFabric_->GHGFStateRow_(slot, SR::EFFECTIVE_PRECISION);
        float* value_variance =
            GHGFFabric_->GHGFErrorRow_(slot, ER::VALUE_PREDICTION_ERROR);
        float* log_volatility =
            GHGFFabric_->GHGFErrorRow_(slot, ER::VOLATILE_PREDICTION_ERROR);

        const float auto_connection = weight[static_cast<size_t>(EI::AUTO_CONNECTION)];
        const float tonic_drift = weight[static_cast<size_t>(EI::TONIC_DRIFT)];
        const float tonic_volatility = weight[static_cast<size_t>(EI::TONIC_VOLATILE)];

        for (uint32_t lane = 0; lane < batch; ++lane)
        {
            predicted[lane] = auto_connection * mean[lane] + tonic_drift;
            current_variance[lane] = SC::ONE / precision[lane];
            value_variance[lane] = SC::ZERO;
            log_volatility[lane] = tonic_volatility;
        }

        GM::GHGFParentExecutionSnapshot parents{};
        if (
            GHGFFabric_->ReadGHGFParentExecutionSnapshot_(
                slot,
                value_axis,
                parents,
                max_tries
            ) != FabricToAPCLinker::SeqLockedOperation::FOUND
        )
        {
            return false;
        }

        // H/value-parent contribution.
        for (
            uint64_t mask = parents.ParentMask;
            mask;
            mask &= mask - 1u
        )
        {
            const uint8_t ordinal = static_cast<uint8_t>(std::countr_zero(mask));
            const uint32_t parent = parents.ParentHandles[ordinal].Slot;
            const float coupling = parents.Couplings[ordinal];

            const float* parent_mean =
                GHGFFabric_->FBRowGHGF_(parent, FR::EXPECTED_MEAN);
            const float* parent_precision =
                GHGFFabric_->FBRowGHGF_(parent, FR::EXPECTED_PRECISION);

            const float coupling_squared = coupling * coupling;

            for (uint32_t lane = 0; lane < batch; ++lane)
            {
                predicted[lane] += coupling * parent_mean[lane];
                value_variance[lane] += coupling_squared / parent_precision[lane];
            }
        }

        parents = GM::GHGFParentExecutionSnapshot{};
        if (
            GHGFFabric_->ReadGHGFParentExecutionSnapshot_(
                slot,
                volatile_axis,
                parents,
                max_tries
            ) != FabricToAPCLinker::SeqLockedOperation::FOUND
        )
        {
            return false;
        }

        // V/volatility-parent contribution.

        for (uint64_t mask = parents.ParentMask;
            mask;
            mask &= mask - 1u)
        {
            const uint8_t ordinal = static_cast<uint8_t>(std::countr_zero(mask));
            const uint32_t parent = parents.ParentHandles[ordinal].Slot;
            const float coupling = parents.Couplings[ordinal];

            const float* parent_mean =
                GHGFFabric_->FBRowGHGF_(parent, FR::MEAN);
            const float* parent_precision =
                GHGFFabric_->FBRowGHGF_(parent, FR::EXPECTED_PRECISION);

            const float half_coupling_squared = SC::HALF * coupling * coupling;

            for (uint32_t lane = 0; lane < batch; ++lane)
            {
                log_volatility[lane] +=
                    coupling * parent_mean[lane] +
                    half_coupling_squared / parent_precision[lane];
            }
        }

        // Final predicted precision terms.
        for (uint32_t lane = 0; lane < batch; ++lane)
        {
            const float volatility = std::exp(log_volatility[lane]);
            const float variance = current_variance[lane] + volatility;

            conditional[lane] = SC::ONE / variance;
            marginal[lane] = SC::ONE / (variance + value_variance[lane]);
            effective[lane] = volatility * marginal[lane];

            if (
                !std::isfinite(predicted[lane]) ||
                !std::isfinite(volatility) ||
                volatility <= SC::ZERO ||
                !std::isfinite(conditional[lane]) ||
                conditional[lane] <= SC::ZERO ||
                !std::isfinite(marginal[lane]) ||
                marginal[lane] <= SC::ZERO ||
                !std::isfinite(effective[lane]))
            {
                return false;
            }
        }

        PublishFBackwardMessageGHGF_(batch);
        return true;
    }


    bool GHGFNode::UpdateGHGFNodeNONVectorized_(uint32_t batch, uint32_t max_tries) noexcept
    {
        using SR = GM::GHGFStateRow;
        using SC = GM::StorageConst;

        const uint32_t slot = APCCache_.APCSlotIdx_;
        float* mean = GHGFFabric_->GHGFStateRow_(slot, SR::MEAN);
        float* precision = GHGFFabric_->GHGFStateRow_(slot, SR::PRECISION);
        const float* predicted = GHGFFabric_->GHGFStateRow_(slot, SR::EXPECTED_MEAN);
        const float* marginal = GHGFFabric_->GHGFStateRow_(slot, SR::EXPECTED_PRECISION);
        float* value_error = GHGFFabric_->GHGFErrorRow_(slot, GM::GHGFErrorRow::VALUE_PREDICTION_ERROR);
        float* volatile_error = GHGFFabric_->GHGFErrorRow_(slot, GM::GHGFErrorRow::VOLATILE_PREDICTION_ERROR);

        GM::GHGFParentExecutionSnapshot parents{};
        if (
            GHGFFabric_->ReadGHGFParentExecutionSnapshot_(
                slot,
                FabricSegments::VOLATILE_PARENT_EDGE_TABLE_V,
                parents,
                max_tries
            ) != FabricToAPCLinker::SeqLockedOperation::FOUND
        )
        {
            return false;
        }
        const unsigned volatile_parents = std::popcount(parents.ParentMask);
        const float divisor = static_cast<float>(std::max(1u, volatile_parents));
        for (uint32_t lane = 0; lane < batch; ++lane)
        {
            if (!std::isfinite(precision[lane]) || !std::isfinite(value_error[lane]))
            {
                return false;
            }
            precision[lane] = std::clamp(precision[lane], SC::MIN_PRECISION, SC::MAX_PRECISION);
            mean[lane] = predicted[lane] + value_error[lane] / precision[lane];
            value_error[lane] = mean[lane] - predicted[lane];
            volatile_error[lane] = (marginal[lane] / precision[lane] +
                marginal[lane] * value_error[lane] * value_error[lane] - SC::ONE) / divisor;
            if (!std::isfinite(mean[lane]) || !std::isfinite(volatile_error[lane]))
            {
                return false;
            }
        }
        return PublishFForwardMessageGHGF_(batch);
    }
    
    bool GHGFNode::PropogateGHGFErrorNONVectorized_(
        uint32_t child,
        uint32_t batch,
        uint32_t max_tries
    ) noexcept
    {
        using SR = GM::GHGFStateRow;
        using ER = GM::GHGFErrorRow;
        using FR = GM::GHGFMessageFForward;

        if (child != APCCache_.APCSlotIdx_)
            return false;

        const float* value_factor = GHGFFabric_->FFRowGHGF_(child, FR::VALUE_FACTOR);
        const float* value_gain = GHGFFabric_->FFRowGHGF_(child, FR::VALUE_GAIN);
        const float* value_error = GHGFFabric_->FFRowGHGF_(child, FR::VALUE_ERROR);
        const float* effictive_precision = GHGFFabric_->FFRowGHGF_(child, FR::EFFECTIVE_PRECISION);
        const float* volatile_error = GHGFFabric_->FFRowGHGF_(child, FR::VOLATILE_ERROR);

        for (FabricSegments edge :
            {
                FabricSegments::VALUE_PARENT_EDGE_TABLE_H,
                FabricSegments::VOLATILE_PARENT_EDGE_TABLE_V
            })
        {

            GM::GHGFParentExecutionSnapshot parents{};
            if (
                GHGFFabric_->ReadGHGFParentExecutionSnapshot_(
                    child,
                    edge,
                    parents,
                    max_tries
                ) != FabricToAPCLinker::SeqLockedOperation::FOUND
            )
            {
                return false;
            }

            for (
                uint64_t mask = parents.ParentMask;
                mask;
                mask &= mask - 1u
            )
            {
                const uint8_t ordinal = static_cast<uint8_t>(std::countr_zero(mask));
                const uint32_t parent = parents.ParentHandles[ordinal].Slot;
                const float coupling = parents.Couplings[ordinal];

                const float coupling_squared = coupling * coupling;
                

                float* parent_precision =
                    GHGFFabric_->GHGFStateRow_(parent, SR::PRECISION);

                float* parent_correction =
                    GHGFFabric_->GHGFErrorRow_(
                        parent,
                        ER::VALUE_PREDICTION_ERROR
                    );

                
                if (edge == FabricSegments::VALUE_PARENT_EDGE_TABLE_H)
                {
                    for (uint32_t lane = 0; lane < batch; ++lane)
                    {

                            parent_precision[lane] +=
                                coupling_squared * value_factor[lane];

                            parent_correction[lane] +=
                                coupling * value_gain[lane] * value_error[lane];
                    }
                }
                else
                {
                    for (uint32_t lane = 0; lane < batch; ++lane)
                    {
                        const float weighted_effective =
                            coupling * effictive_precision[lane];

                        const float weighted_effective_sq =
                            weighted_effective * weighted_effective;

                        parent_precision[lane] +=
                            GM::StorageConst::HALF * weighted_effective_sq +
                            weighted_effective_sq * volatile_error[lane] -
                            GM::StorageConst::HALF *
                                coupling_squared *
                                effictive_precision[lane] *
                                volatile_error[lane];

                        parent_correction[lane] +=
                            GM::StorageConst::HALF *
                            weighted_effective *
                            volatile_error[lane];
                    }
                }
            }
        }

        return true;
    }
}